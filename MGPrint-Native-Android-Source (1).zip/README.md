# MGPrint Native Android

MGPrint, **Kotlin + Jetpack Compose** ile yazılmış yerel Android kaynak projesidir. Expo veya JavaScript çalışma zamanı içermez.

## Android Studio ile açma

Android Studio'da bu klasörü açın. IDE, Android SDK Platform 35 ve JDK 17 için yol sorarsa kendi kurulumunuzu seçin. Ardından Gradle eşitlemesini başlatın.

## Komut satırından derleme

Linux/macOS:

```bash
chmod +x gradlew
./gradlew assembleDebug
```

Windows:

```bat
gradlew.bat assembleDebug
```

İlk komut, Gradle 8.10.2 dağıtımını güvenilir Gradle sunucusundan indirir. Android SDK'nın `ANDROID_HOME` veya `ANDROID_SDK_ROOT` ile erişilebilir olması gerekir. Oluşan APK `app/build/outputs/apk/debug/app-debug.apk` yolundadır.

## Uygulanan özellikler

Uygulama PDF ve fotoğraf seçimi, CameraX ile belge fotoğrafı çekme/döndürme, Android Print Framework üzerinden PDF ve görsel yazdırma, yerel baskı tercihleri, Türkçe/İngilizce arayüz ve mDNS/NSD tabanlı IPP yazıcı keşfi içerir. Office ve ODT dosyaları Android paylaşım/açma akışıyla uyumlu yazdırma uygulamasına aktarılır; bu formatların uygulama içinde yerel sayfa motoruyla işlenmesi ayrı bir belge dönüştürme katmanı gerektirir.

> Ham Raw Socket 9100, LPD/LPR, USB OTG ve Bluetooth yazdırma için üretici uyumluluğu gerektiren ayrı bağlantı katmanları gerekir. Bu kaynak sürüm, Android'in kurulu Mopria veya üretici yazdırma hizmetiyle çalışan sistem yazdırma akışını kullanır.
