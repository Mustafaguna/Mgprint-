# Project-specific R8 rules are not required for the initial MGPrint build.
