package com.mgprint.app.data

import org.junit.Assert.assertEquals
import org.junit.Test
import java.util.Locale

class ModelsTest {
    @Test
    fun `explicit language choice takes priority`() {
        assertEquals(AppLanguage.TURKISH, activeLanguage(AppLanguage.TURKISH))
        assertEquals(AppLanguage.ENGLISH, activeLanguage(AppLanguage.ENGLISH))
    }

    @Test
    fun `print settings have safe defaults`() {
        val settings = PrintSettings()
        assertEquals(ColorMode.COLOR, settings.colorMode)
        assertEquals("A4", settings.paperSize)
        assertEquals(1, settings.copies)
        assertEquals(FitMode.FIT, settings.fitMode)
    }
}
