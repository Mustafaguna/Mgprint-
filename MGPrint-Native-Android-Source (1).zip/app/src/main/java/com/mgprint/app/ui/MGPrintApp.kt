package com.mgprint.app.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.mgprint.app.data.AppLanguage
import com.mgprint.app.data.ColorMode
import com.mgprint.app.data.DuplexMode
import com.mgprint.app.data.FitMode
import com.mgprint.app.data.JobType
import com.mgprint.app.data.Orientation
import com.mgprint.app.data.PreferenceRepository
import com.mgprint.app.data.PrintJob
import com.mgprint.app.data.PrintSettings
import com.mgprint.app.data.UserPreferences
import com.mgprint.app.data.activeLanguage
import com.mgprint.app.discovery.PrinterDiscoveryManager
import com.mgprint.app.printing.PrintSupport
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

private enum class Screen { HOME, PREVIEW, SCANNER, PRINTERS, SETTINGS }

private data class Copy(
    val subtitle: String,
    val document: String,
    val documentHelp: String,
    val photo: String,
    val photoHelp: String,
    val scan: String,
    val scanHelp: String,
    val printers: String,
    val printersHelp: String,
    val printerStatus: String,
    val noPrinter: String,
    val printPreview: String,
    val printOptions: String,
    val color: String,
    val colorValue: String,
    val monoValue: String,
    val paper: String,
    val orientation: String,
    val portrait: String,
    val landscape: String,
    val duplex: String,
    val oneSided: String,
    val longEdge: String,
    val shortEdge: String,
    val copies: String,
    val pageRange: String,
    val fit: String,
    val fill: String,
    val print: String,
    val rotate: String,
    val settings: String,
    val language: String,
    val system: String,
    val printService: String,
    val printServiceHelp: String,
    val openPrintSettings: String,
    val connectionOptions: String,
    val noJob: String,
    val chooseFirst: String,
    val nativeLimit: String
)

private fun copy(language: AppLanguage): Copy = if (language == AppLanguage.TURKISH) {
    Copy(
        "Kolay ve güvenli yazdırma", "Belge Yazdır", "PDF, Office, metin ve diğer dosyaları seçin",
        "Fotoğraf Yazdır", "Galeriden bir fotoğraf seçin", "Tara ve Yazdır", "Kamerayla belgeyi yakalayın",
        "Yazıcı Tara", "Ağ yazıcılarını ve yazdırma hizmetini kontrol edin", "Yazıcı durumu", "Henüz yazıcı seçilmedi",
        "Baskı önizleme", "Baskı ayarları", "Renk modu", "Renkli", "Siyah-beyaz", "Kağıt boyutu", "Yönlendirme",
        "Dikey", "Yatay", "Çift taraflı", "Tek taraflı", "Uzun kenar", "Kısa kenar", "Kopya sayısı", "Sayfa aralığı",
        "Sayfaya sığdır", "Doldur ve kırp", "Yazdır", "Döndür", "Ayarlar", "Dil", "Sistem dili",
        "Android yazdırma hizmeti", "Mopria veya yazıcı üreticinizin hizmetini Android Ayarları'ndan seçin.",
        "Yazdırma ayarlarını aç", "Bağlantı seçenekleri", "Yazdırılacak içerik yok", "Ana sayfadan belge, fotoğraf veya tarama seçin.",
        "Office/ODT belgeleri uyumlu Android uygulamasıyla açılır. IPP yazıcıları yerel ağda otomatik bulunur."
    )
} else {
    Copy(
        "Simple and reliable printing", "Print document", "Choose PDF, Office, text, and other files",
        "Print photo", "Choose a photo from your library", "Scan and print", "Capture a document with the camera",
        "Find printer", "Check network printers and the print service", "Printer status", "No printer selected yet",
        "Print preview", "Print settings", "Color mode", "Color", "Black and white", "Paper size", "Orientation",
        "Portrait", "Landscape", "Two-sided printing", "One-sided", "Long edge", "Short edge", "Copies", "Page range",
        "Fit to page", "Fill and crop", "Print", "Rotate", "Settings", "Language", "System language",
        "Android print service", "Choose Mopria or your printer manufacturer's service in Android Settings.",
        "Open print settings", "Connection options", "Nothing to print yet", "Choose a document, photo, or scan from the home screen.",
        "Office/ODT documents open with a compatible Android app. IPP printers are discovered on the local network."
    )
}

@Composable
fun MGPrintApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val preferences by PreferenceRepository.observe(context).collectAsState(initial = UserPreferences())
    val active = activeLanguage(preferences.language)
    val text = copy(active)
    var screen by remember { mutableStateOf(Screen.HOME) }
    var job by remember { mutableStateOf<PrintJob?>(null) }

    fun savePreferences(updated: UserPreferences) {
        scope.launch { PreferenceRepository.save(context, updated) }
    }
    fun updateSettings(update: (PrintSettings) -> PrintSettings) {
        savePreferences(preferences.copy(printSettings = update(preferences.printSettings)))
    }

    MGPrintTheme {
        when (screen) {
            Screen.HOME -> HomeScreen(
                text = text,
                activeLanguage = active,
                onDocument = { picked -> job = picked; screen = Screen.PREVIEW },
                onPhoto = { picked -> job = picked; screen = Screen.PREVIEW },
                onScanner = { screen = Screen.SCANNER },
                onPrinters = { screen = Screen.PRINTERS },
                onSettings = { screen = Screen.SETTINGS }
            )
            Screen.PREVIEW -> PreviewScreen(
                text = text,
                job = job,
                settings = preferences.printSettings,
                onBack = { screen = Screen.HOME },
                onSettingsChange = ::updateSettings,
                onRotate = { current -> job = rotateJob(context, current) },
                onPrint = { current -> PrintSupport.print(context, current, preferences.printSettings) }
            )
            Screen.SCANNER -> ScannerCamera(
                tr = active == AppLanguage.TURKISH,
                onBack = { screen = Screen.HOME },
                onImageReady = { uri ->
                    job = PrintJob(uri, "MGPrint-${System.currentTimeMillis()}.jpg", "image/jpeg", JobType.IMAGE)
                    screen = Screen.PREVIEW
                }
            )
            Screen.PRINTERS -> PrintersScreen(text, onBack = { screen = Screen.HOME })
            Screen.SETTINGS -> SettingsScreen(
                text = text,
                language = preferences.language,
                settings = preferences.printSettings,
                onLanguage = { savePreferences(preferences.copy(language = it)) },
                onSettingsChange = ::updateSettings,
                onBack = { screen = Screen.HOME }
            )
        }
    }
}

@Composable
private fun HomeScreen(
    text: Copy,
    activeLanguage: AppLanguage,
    onDocument: (PrintJob) -> Unit,
    onPhoto: (PrintJob) -> Unit,
    onScanner: () -> Unit,
    onPrinters: () -> Unit,
    onSettings: () -> Unit
) {
    val context = LocalContext.current
    val documentPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            runCatching { context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val mime = context.contentResolver.getType(it)
            val type = if (mime == "application/pdf" || fileName(context, it).endsWith(".pdf", true)) JobType.PDF else JobType.DOCUMENT
            onDocument(PrintJob(it, fileName(context, it), mime, type))
        }
    }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { onPhoto(PrintJob(it, fileName(context, it), context.contentResolver.getType(it), JobType.IMAGE)) }
    }
    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(17.dp), color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(56.dp)) {
                        Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Print, null, tint = Color.White, modifier = Modifier.size(31.dp)) }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("MGPrint", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text(text.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, contentDescription = text.settings) }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE9F8F5))) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Print, null, tint = Color(0xFF208B63))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) { Text(text.printerStatus, fontWeight = FontWeight.Bold); Text(text.noPrinter, style = MaterialTheme.typography.bodySmall) }
                        OutlinedButton(onClick = onPrinters) { Text(text.printers) }
                    }
                }
            }
            item { HomeAction(Icons.Default.Description, text.document, text.documentHelp) { documentPicker.launch(arrayOf("application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-powerpoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "text/plain", "text/csv", "application/vnd.oasis.opendocument.text", "image/*")) } }
            item { HomeAction(Icons.Default.Photo, text.photo, text.photoHelp) { photoPicker.launch("image/*") } }
            item { HomeAction(Icons.Default.DocumentScanner, text.scan, text.scanHelp, Color(0xFF5384C6), onScanner) }
            item { HomeAction(Icons.Default.Search, text.printers, text.printersHelp, Color(0xFF336D9E), onPrinters) }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                        Icon(Icons.Default.Info, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text(text.nativeLimit, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeAction(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, detail: String, color: Color? = null, onClick: () -> Unit) {
    val actionColor = color ?: MaterialTheme.colorScheme.primary
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = actionColor, shape = RoundedCornerShape(16.dp), modifier = Modifier.size(54.dp)) { Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = Color.White) } }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium); Text(detail, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall) }
            Icon(Icons.Default.ArrowBack, null, modifier = Modifier.size(20.dp).rotate(180f), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun PreviewScreen(
    text: Copy,
    job: PrintJob?,
    settings: PrintSettings,
    onBack: () -> Unit,
    onSettingsChange: ((PrintSettings) -> PrintSettings) -> Unit,
    onRotate: (PrintJob) -> Unit,
    onPrint: (PrintJob) -> Unit
) {
    Scaffold(topBar = { Header(text.printPreview, onBack) }, containerColor = MaterialTheme.colorScheme.background) { padding ->
        if (job == null) {
            Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(Icons.Default.Print, null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                Text(text.noJob, modifier = Modifier.padding(top = 12.dp), fontWeight = FontWeight.Bold)
                Text(text.chooseFirst, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item { JobPreview(job, text, onRotate) }
                item { Text(text.printOptions, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                item { PrintSettingCard(text, settings, onSettingsChange) }
                item { Button(onClick = { onPrint(job) }, modifier = Modifier.fillMaxWidth().height(56.dp)) { Icon(Icons.Default.Print, null); Spacer(Modifier.width(8.dp)); Text(if (job.type == JobType.DOCUMENT) "Open" else text.print) } }
            }
        }
    }
}

@Composable
private fun JobPreview(job: PrintJob, text: Copy, onRotate: (PrintJob) -> Unit) {
    val context = LocalContext.current
    val bitmap = remember(job.uri) { loadBitmap(context, job.uri) }
    Card {
        Column(Modifier.padding(14.dp)) {
            if (bitmap != null && job.type == JobType.IMAGE) {
                Image(bitmap.asImageBitmap(), null, Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Fit)
                OutlinedButton(onClick = { onRotate(job) }, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 10.dp)) { Icon(Icons.Default.RotateRight, null); Spacer(Modifier.width(6.dp)); Text(text.rotate) }
            } else {
                Box(Modifier.fillMaxWidth().height(180.dp).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) { Icon(Icons.Default.Description, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(58.dp)) }
            }
            Row(Modifier.padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(if (job.type == JobType.IMAGE) Icons.Default.Photo else Icons.Default.Description, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp)); Text(job.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun PrintSettingCard(text: Copy, settings: PrintSettings, onUpdate: ((PrintSettings) -> PrintSettings) -> Unit) {
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SettingLabel(text.color)
            ChoiceRow(listOf(text.colorValue to ColorMode.COLOR, text.monoValue to ColorMode.MONOCHROME), settings.colorMode) { newValue -> onUpdate { current -> current.copy(colorMode = newValue) } }
            SettingLabel(text.paper)
            ChoiceRow(listOf("A4" to "A4", "A3" to "A3", "Letter" to "Letter", "Legal" to "Legal", "10×15" to "Photo"), settings.paperSize) { newValue -> onUpdate { it.copy(paperSize = newValue) } }
            SettingLabel(text.orientation)
            ChoiceRow(listOf(text.portrait to Orientation.PORTRAIT, text.landscape to Orientation.LANDSCAPE), settings.orientation) { newValue -> onUpdate { it.copy(orientation = newValue) } }
            SettingLabel(text.duplex)
            ChoiceRow(listOf(text.oneSided to DuplexMode.NONE, text.longEdge to DuplexMode.LONG_EDGE, text.shortEdge to DuplexMode.SHORT_EDGE), settings.duplexMode) { newValue -> onUpdate { it.copy(duplexMode = newValue) } }
            SettingLabel("${text.fit}: ${text.fill}")
            ChoiceRow(listOf(text.fit to FitMode.FIT, text.fill to FitMode.FILL), settings.fitMode) { newValue -> onUpdate { it.copy(fitMode = newValue) } }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text.copies, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = { onUpdate { it.copy(copies = (it.copies - 1).coerceAtLeast(1)) } }) { Text("−") }
                Text(settings.copies.toString(), modifier = Modifier.padding(horizontal = 14.dp), fontWeight = FontWeight.Bold)
                OutlinedButton(onClick = { onUpdate { it.copy(copies = (it.copies + 1).coerceAtMost(99)) } }) { Text("+") }
            }
            OutlinedTextField(value = if (settings.pageRange == "all") "" else settings.pageRange, onValueChange = { value -> onUpdate { it.copy(pageRange = value.ifBlank { "all" }) } }, label = { Text(text.pageRange) }, placeholder = { Text("All") }, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun SettingLabel(value: String) { Text(value, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium) }

@Composable
private fun <T> ChoiceRow(options: List<Pair<String, T>>, selected: T, onSelected: (T) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        options.forEach { (label, value) -> FilterChip(selected = value == selected, onClick = { onSelected(value) }, label = { Text(label) }) }
    }
}

@Composable
private fun PrintersScreen(text: Copy, onBack: () -> Unit) {
    val context = LocalContext.current
    val discovery = remember { PrinterDiscoveryManager(context) }
    val printers by discovery.printers.collectAsState()
    LaunchedEffect(Unit) { discovery.start() }
    DisposableEffect(Unit) { onDispose { discovery.stop() } }
    Scaffold(topBar = { Header(text.printers, onBack) }, containerColor = MaterialTheme.colorScheme.background) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF6FA))) {
                    Column(Modifier.padding(18.dp)) {
                        Icon(Icons.Default.Print, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                        Text(text.printService, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                        Text(text.printServiceHelp, style = MaterialTheme.typography.bodySmall)
                        Button(onClick = { runCatching { context.startActivity(Intent(Settings.ACTION_PRINT_SETTINGS)) } }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) { Text(text.openPrintSettings) }
                    }
                }
            }
            item { Text("IPP / IPPS mDNS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            if (printers.isEmpty()) item { Text("…", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(printers) { printer -> Card { Column(Modifier.padding(14.dp)) { Text(printer.name, fontWeight = FontWeight.Bold); Text("ipp://${printer.host}:${printer.port}", style = MaterialTheme.typography.bodySmall) } } }
            item { Text(text.connectionOptions, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
            item { ConnectionRow(Icons.Default.Wifi, "Wi‑Fi / LAN", "IPP/IPPS ve Android yazdırma hizmetleri") }
            item { ConnectionRow(Icons.Default.Bluetooth, "Bluetooth / BLE", "Üretici hizmeti desteklediğinde") }
            item { ConnectionRow(Icons.Default.Usb, "USB OTG", "Uyumlu yazdırma hizmeti ve kablo ile") }
        }
    }
}

@Composable
private fun ConnectionRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Card { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(12.dp)); Column { Text(title, fontWeight = FontWeight.Bold); Text(subtitle, style = MaterialTheme.typography.bodySmall) } } }
}

@Composable
private fun SettingsScreen(text: Copy, language: AppLanguage, settings: PrintSettings, onLanguage: (AppLanguage) -> Unit, onSettingsChange: ((PrintSettings) -> PrintSettings) -> Unit, onBack: () -> Unit) {
    Scaffold(topBar = { Header(text.settings, onBack) }, containerColor = MaterialTheme.colorScheme.background) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Text(text.language, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            item { LanguageOption("${text.system}", language == AppLanguage.SYSTEM) { onLanguage(AppLanguage.SYSTEM) } }
            item { LanguageOption("Türkçe", language == AppLanguage.TURKISH) { onLanguage(AppLanguage.TURKISH) } }
            item { LanguageOption("English", language == AppLanguage.ENGLISH) { onLanguage(AppLanguage.ENGLISH) } }
            item { HorizontalDivider(Modifier.padding(vertical = 6.dp)) }
            item { Text(text.printOptions, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            item { PrintSettingCard(text, settings, onSettingsChange) }
        }
    }
}

@Composable
private fun LanguageOption(label: String, selected: Boolean, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text(label, modifier = Modifier.weight(1f)); RadioButton(selected, onClick) } }
}

@Composable
private fun Header(title: String, onBack: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.background) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = null) }
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

private fun fileName(context: Context, uri: Uri): String {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) return cursor.getString(cursor.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
    }
    return uri.lastPathSegment ?: "MGPrint document"
}

private fun loadBitmap(context: Context, uri: Uri): Bitmap? = runCatching {
    context.contentResolver.openInputStream(uri)?.use(BitmapFactory::decodeStream) ?: BitmapFactory.decodeFile(uri.path)
}.getOrNull()

private fun rotateJob(context: Context, job: PrintJob): PrintJob {
    val bitmap = loadBitmap(context, job.uri) ?: return job
    val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, Matrix().apply { postRotate(90f) }, true)
    val output = File(context.cacheDir, "MGPrint-rotated-${System.currentTimeMillis()}.jpg")
    FileOutputStream(output).use { rotated.compress(Bitmap.CompressFormat.JPEG, 92, it) }
    return job.copy(uri = Uri.fromFile(output), name = "rotated-${job.name}", mimeType = "image/jpeg")
}
