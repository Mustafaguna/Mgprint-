package com.mgprint.app.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import java.io.File

@Composable
fun ScannerCamera(
    tr: Boolean,
    onBack: () -> Unit,
    onImageReady: (Uri) -> Unit
) {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) permissionLauncher.launch(Manifest.permission.CAMERA) }

    if (!granted) {
        PermissionScreen(tr, onBack) { permissionLauncher.launch(Manifest.permission.CAMERA) }
    } else {
        CameraPreview(tr, onBack, onImageReady)
    }
}

@Composable
private fun PermissionScreen(tr: Boolean, onBack: () -> Unit, onGrant: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.CameraAlt, null, tint = MaterialTheme.colorScheme.primary)
        Text(if (tr) "Tarama için kamera izni gerekli" else "Camera permission is required for scanning", modifier = Modifier.padding(top = 12.dp))
        Button(onClick = onGrant, modifier = Modifier.padding(top = 18.dp)) { Text(if (tr) "Kamera izni ver" else "Allow camera") }
        Button(onClick = onBack, modifier = Modifier.padding(top = 8.dp), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) { Text(if (tr) "Vazgeç" else "Cancel") }
    }
}

@Composable
private fun CameraPreview(tr: Boolean, onBack: () -> Unit, onImageReady: (Uri) -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val executor = remember { ContextCompat.getMainExecutor(context) }
    val cameraProviderFuture = remember { ProcessCameraProvider.getInstance(context) }
    val previewView = remember { PreviewView(context) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }

    DisposableEffect(lifecycleOwner) {
        val listener = Runnable {
            val provider = cameraProviderFuture.get()
            val preview = androidx.camera.core.Preview.Builder().build()
            val capture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            provider.unbindAll()
            provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture)
            imageCapture = capture
        }
        cameraProviderFuture.addListener(listener, executor)
        onDispose { runCatching { cameraProviderFuture.get().unbindAll() } }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
        IconButton(onClick = onBack, modifier = Modifier.align(Alignment.TopStart).padding(16.dp)) {
            Icon(Icons.Default.Close, contentDescription = null, tint = Color.White)
        }
        Column(modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(PaddingValues(bottom = 30.dp, start = 24.dp, end = 24.dp)), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (tr) "Belgeyi çerçevenin içinde tutun" else "Keep the document inside the frame", color = Color.White)
            Button(onClick = { imageCapture?.takePhoto(context, executor, onImageReady) }, modifier = Modifier.padding(top = 12.dp)) { Text(if (tr) "Belgeyi çek" else "Capture document") }
        }
    }
}

private fun ImageCapture.takePhoto(context: Context, executor: java.util.concurrent.Executor, onImageReady: (Uri) -> Unit) {
    val output = File(context.cacheDir, "MGPrint-${System.currentTimeMillis()}.jpg")
    val options = ImageCapture.OutputFileOptions.Builder(output).build()
    takePicture(options, executor, object : ImageCapture.OnImageSavedCallback {
        override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) = onImageReady(Uri.fromFile(output))
        override fun onError(exception: ImageCaptureException) = Unit
    })
}
