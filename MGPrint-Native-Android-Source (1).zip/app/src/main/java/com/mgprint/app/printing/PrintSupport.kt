package com.mgprint.app.printing

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.print.pdf.PrintedPdfDocument
import androidx.core.content.ContextCompat
import com.mgprint.app.data.ColorMode
import com.mgprint.app.data.DuplexMode
import com.mgprint.app.data.FitMode
import com.mgprint.app.data.JobType
import com.mgprint.app.data.Orientation
import com.mgprint.app.data.PrintJob
import com.mgprint.app.data.PrintSettings
import java.io.FileOutputStream

object PrintSupport {
    fun print(context: Context, job: PrintJob, settings: PrintSettings) {
        if (job.type == JobType.DOCUMENT) {
            openWithCompatibleApp(context, job)
            return
        }
        val manager = context.getSystemService(PrintManager::class.java)
        val attributes = settings.toPrintAttributes()
        val adapter = if (job.type == JobType.PDF) {
            PdfUriPrintAdapter(context, job.uri, job.name)
        } else {
            ImageUriPrintAdapter(context, job.uri, job.name, settings)
        }
        manager.print(job.name, adapter, attributes)
    }

    private fun openWithCompatibleApp(context: Context, job: PrintJob) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(job.uri, job.mimeType ?: "application/octet-stream")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ContextCompat.startActivity(context, Intent.createChooser(intent, "MGPrint"), null)
    }
}

private fun PrintSettings.toPrintAttributes(): PrintAttributes {
    val mediaSize = when (paperSize) {
        "A3" -> PrintAttributes.MediaSize.ISO_A3
        "Letter" -> PrintAttributes.MediaSize.NA_LETTER
        "Legal" -> PrintAttributes.MediaSize.NA_LEGAL
        "Photo" -> PrintAttributes.MediaSize.NA_INDEX_4X6
        else -> PrintAttributes.MediaSize.ISO_A4
    }
    val orientedSize = if (orientation == Orientation.LANDSCAPE) mediaSize.asLandscape() else mediaSize.asPortrait()
    val color = if (colorMode == ColorMode.MONOCHROME) PrintAttributes.COLOR_MODE_MONOCHROME else PrintAttributes.COLOR_MODE_COLOR
    val duplex = when (duplexMode) {
        DuplexMode.LONG_EDGE -> PrintAttributes.DUPLEX_MODE_LONG_EDGE
        DuplexMode.SHORT_EDGE -> PrintAttributes.DUPLEX_MODE_SHORT_EDGE
        DuplexMode.NONE -> PrintAttributes.DUPLEX_MODE_NONE
    }
    return PrintAttributes.Builder()
        .setMediaSize(orientedSize)
        .setColorMode(color)
        .setDuplexMode(duplex)
        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
        .build()
}

private class PdfUriPrintAdapter(
    private val context: Context,
    private val uri: Uri,
    private val title: String
) : PrintDocumentAdapter() {
    override fun onLayout(
        oldAttributes: PrintAttributes?,
        newAttributes: PrintAttributes,
        cancellationSignal: CancellationSignal,
        callback: LayoutResultCallback,
        extras: Bundle?
    ) {
        callback.onLayoutFinished(
            PrintDocumentInfo.Builder(title).setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN).build(),
            oldAttributes != newAttributes
        )
    }

    override fun onWrite(
        pages: Array<PageRange>,
        destination: ParcelFileDescriptor,
        cancellationSignal: CancellationSignal,
        callback: WriteResultCallback
    ) {
        try {
            context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "PDF cannot be opened" }
                FileOutputStream(destination.fileDescriptor).use { output -> input.copyTo(output) }
            }
            callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
        } catch (error: Exception) {
            callback.onWriteFailed(error.message)
        }
    }
}

private class ImageUriPrintAdapter(
    private val context: Context,
    private val uri: Uri,
    private val title: String,
    private val settings: PrintSettings
) : PrintDocumentAdapter() {
    private var attributes: PrintAttributes? = null

    override fun onLayout(
        oldAttributes: PrintAttributes?,
        newAttributes: PrintAttributes,
        cancellationSignal: CancellationSignal,
        callback: LayoutResultCallback,
        extras: Bundle?
    ) {
        attributes = newAttributes
        callback.onLayoutFinished(
            PrintDocumentInfo.Builder(title).setContentType(PrintDocumentInfo.CONTENT_TYPE_PHOTO).setPageCount(1).build(),
            oldAttributes != newAttributes
        )
    }

    override fun onWrite(
        pages: Array<PageRange>,
        destination: ParcelFileDescriptor,
        cancellationSignal: CancellationSignal,
        callback: WriteResultCallback
    ) {
        val currentAttributes = attributes ?: run {
            callback.onWriteFailed("Print settings are unavailable")
            return
        }
        try {
            val bitmap = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                ?: BitmapFactory.decodeFile(uri.path)
                ?: error("Image cannot be opened")
            val document = PrintedPdfDocument(context, currentAttributes)
            val page = document.startPage(0)
            drawBitmap(page.canvas, bitmap, page.info.pageWidth.toFloat(), page.info.pageHeight.toFloat(), settings)
            document.finishPage(page)
            FileOutputStream(destination.fileDescriptor).use { document.writeTo(it) }
            document.close()
            callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
        } catch (error: Exception) {
            callback.onWriteFailed(error.message)
        }
    }

    private fun drawBitmap(canvas: Canvas, bitmap: Bitmap, pageWidth: Float, pageHeight: Float, settings: PrintSettings) {
        val sourceRatio = bitmap.width.toFloat() / bitmap.height.toFloat()
        val pageRatio = pageWidth / pageHeight
        val scale = if (settings.fitMode == FitMode.FILL) {
            if (sourceRatio > pageRatio) pageHeight / bitmap.height else pageWidth / bitmap.width
        } else {
            if (sourceRatio > pageRatio) pageWidth / bitmap.width else pageHeight / bitmap.height
        }
        val width = bitmap.width * scale
        val height = bitmap.height * scale
        val destination = RectF((pageWidth - width) / 2f, (pageHeight - height) / 2f, (pageWidth + width) / 2f, (pageHeight + height) / 2f)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        if (settings.colorMode == ColorMode.MONOCHROME) {
            paint.colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
        }
        canvas.drawBitmap(bitmap, null, destination, paint)
    }
}
