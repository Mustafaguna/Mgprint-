package com.mgprint.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF123B6D),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFEAF6FA),
    secondary = Color(0xFF14B8C4),
    background = Color(0xFFEEF7FB),
    surface = Color.White,
    onBackground = Color(0xFF142033),
    onSurface = Color(0xFF142033),
    outline = Color(0xFFD6E4EA)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4EBFCB),
    secondary = Color(0xFF79DCE5),
    background = Color(0xFF0D1826),
    surface = Color(0xFF142438),
    onBackground = Color(0xFFF1F7FA),
    onSurface = Color(0xFFF1F7FA),
    outline = Color(0xFF2A4058)
)

@Composable
fun MGPrintTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LightColors, typography = AppTypography, content = content)
}
