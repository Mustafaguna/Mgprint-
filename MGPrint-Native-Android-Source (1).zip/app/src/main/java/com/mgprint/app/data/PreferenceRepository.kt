package com.mgprint.app.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "mgprint_preferences")

object PreferenceRepository {
    private val languageKey = stringPreferencesKey("language")
    private val colorModeKey = stringPreferencesKey("color_mode")
    private val paperSizeKey = stringPreferencesKey("paper_size")
    private val orientationKey = stringPreferencesKey("orientation")
    private val duplexKey = stringPreferencesKey("duplex")
    private val copiesKey = intPreferencesKey("copies")
    private val pageRangeKey = stringPreferencesKey("page_range")
    private val fitModeKey = stringPreferencesKey("fit_mode")

    fun observe(context: Context): Flow<UserPreferences> = context.dataStore.data.map { values ->
        UserPreferences(
            language = values.enumValue(languageKey, AppLanguage.SYSTEM),
            printSettings = PrintSettings(
                colorMode = values.enumValue(colorModeKey, ColorMode.COLOR),
                paperSize = values[paperSizeKey] ?: "A4",
                orientation = values.enumValue(orientationKey, Orientation.PORTRAIT),
                duplexMode = values.enumValue(duplexKey, DuplexMode.NONE),
                copies = (values[copiesKey] ?: 1).coerceIn(1, 99),
                pageRange = values[pageRangeKey] ?: "all",
                fitMode = values.enumValue(fitModeKey, FitMode.FIT)
            )
        )
    }

    suspend fun save(context: Context, preferences: UserPreferences) {
        context.dataStore.edit { values ->
            values[languageKey] = preferences.language.name
            values[colorModeKey] = preferences.printSettings.colorMode.name
            values[paperSizeKey] = preferences.printSettings.paperSize
            values[orientationKey] = preferences.printSettings.orientation.name
            values[duplexKey] = preferences.printSettings.duplexMode.name
            values[copiesKey] = preferences.printSettings.copies
            values[pageRangeKey] = preferences.printSettings.pageRange
            values[fitModeKey] = preferences.printSettings.fitMode.name
        }
    }

    private inline fun <reified T : Enum<T>> Preferences.enumValue(
        key: Preferences.Key<String>,
        fallback: T
    ): T = this[key]?.let { runCatching { enumValueOf<T>(it) }.getOrNull() } ?: fallback
}
