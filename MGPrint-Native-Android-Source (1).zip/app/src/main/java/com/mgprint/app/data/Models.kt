package com.mgprint.app.data

import android.net.Uri
import java.util.Locale

enum class AppLanguage { SYSTEM, TURKISH, ENGLISH }
enum class JobType { PDF, IMAGE, DOCUMENT }
enum class ColorMode { COLOR, MONOCHROME }
enum class Orientation { PORTRAIT, LANDSCAPE }
enum class DuplexMode { NONE, LONG_EDGE, SHORT_EDGE }
enum class FitMode { FIT, FILL }

data class PrintJob(
    val uri: Uri,
    val name: String,
    val mimeType: String?,
    val type: JobType
)

data class PrintSettings(
    val colorMode: ColorMode = ColorMode.COLOR,
    val paperSize: String = "A4",
    val orientation: Orientation = Orientation.PORTRAIT,
    val duplexMode: DuplexMode = DuplexMode.NONE,
    val copies: Int = 1,
    val pageRange: String = "all",
    val fitMode: FitMode = FitMode.FIT
)

data class UserPreferences(
    val language: AppLanguage = AppLanguage.SYSTEM,
    val printSettings: PrintSettings = PrintSettings()
)

data class DiscoveredPrinter(
    val name: String,
    val host: String,
    val port: Int,
    val serviceType: String
)

fun activeLanguage(preference: AppLanguage): AppLanguage = when (preference) {
    AppLanguage.SYSTEM -> if (Locale.getDefault().language.equals("tr", ignoreCase = true)) AppLanguage.TURKISH else AppLanguage.ENGLISH
    else -> preference
}
