package com.mgprint.app.ui

import androidx.compose.material3.Typography

val AppTypography = Typography()
