# Native Android Rebuild TODO

- [x] Android Studio ve Gradle uyumlu Kotlin proje iskeletini oluştur
- [x] Jetpack Compose tema, MGPrint kimliği ve Türkçe/İngilizce kaynaklarını ekle
- [x] Belge ve fotoğraf seçme akışlarını uygula
- [x] CameraX tabanlı belge tarama ve döndürme akışını ekle
- [x] Android Print Framework ile PDF ve görsel yazdırmayı uygula
- [x] Ağ yazıcısı için mDNS/NSD keşfi ve bağlantı rehberini ekle
- [x] Yazdırma ayarları, yerel tercihler ve erişilebilir ana ekranı uygula
- [ ] Gradle doğrulaması ve kaynak kod ZIP arşivini oluştur
